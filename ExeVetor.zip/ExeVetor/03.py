nota = list(map(float, input().split()))
item = 0
for i in nota:
    item = item + i

print(item / len(nota))
#    print("1 nota: , 2 nota: , 3 nota: ,4 nota: , Média:")(nota, (((n1+n2+n3+n4)/4)))