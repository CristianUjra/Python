nums = list(map(int, input().split()))
for i in nums:
    print(i)
