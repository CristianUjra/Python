nums = list(map(float, input().split()))
nums.sort(reverse=True)
print(nums)
